#!/bin/bash

./halite -d "30 30" "ruby MyBot.rb" "ruby RandomBot.rb"
