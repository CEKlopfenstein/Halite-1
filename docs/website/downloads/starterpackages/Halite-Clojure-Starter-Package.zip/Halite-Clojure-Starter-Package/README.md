# halite-clj

A Clojure implementation of a random Halite bot.

## Usage

First, copy the "halite" executable to the root of your project.  Build using "lein uberjar" and run:

./halite -d "30 30" "java -cp target/MyBot.jar MyBot" "java -cp target/MyBot.jar RandomBot"
