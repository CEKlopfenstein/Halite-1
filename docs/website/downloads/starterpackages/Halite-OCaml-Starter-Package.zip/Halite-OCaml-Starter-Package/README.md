Halite OCaml Starter Package
----------------------------

This is an OCaml starter package for Halite on halite.io

It uses lowercase letters and underscores for variable and function names (following the OCaml convention), but otherwise matches the API seen in other starter packages.

