#!/bin/bash

./halite -d "30 30" "php MyBot.php" "php RandomBot.php"
