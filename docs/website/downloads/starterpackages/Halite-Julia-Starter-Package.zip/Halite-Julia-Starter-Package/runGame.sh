#!/bin/bash

./halite -d "30 30" "julia MyBot.jl" "julia RandomBot.jl"
